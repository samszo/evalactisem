#!/bin/bash

# Build config for the build script, build.sh. Look there for more info.

APP_NAME=helloworld
CHROME_PROVIDERS="content locale skin"
CLEAN_UP=1
ROOT_FILES="readme.txt"
ROOT_DIRS=
BEFORE_BUILD=
AFTER_BUILD=
